#include "location_service.h"

#include "../utils/geo_utils.h"

namespace location {

void LocationService::registerDriver(const Driver& driver) {
    drivers_[driver.id] = driver;
}

void LocationService::registerRider(const Rider& rider) {
    riders_[rider.id] = rider;
}

bool LocationService::updateDriverLocation(const std::string& driverId, const Location& loc) {
    if (!geo::isValidLocation(loc)) return false;
    auto it = drivers_.find(driverId);
    if (it == drivers_.end()) return false;
    it->second.location = loc;
    it->second.location.updatedAt = std::chrono::system_clock::now();
    return true;
}

bool LocationService::updateRiderLocation(const std::string& riderId, const Location& loc) {
    if (!geo::isValidLocation(loc)) return false;
    auto it = riders_.find(riderId);
    if (it == riders_.end()) return false;
    it->second.location = loc;
    it->second.location.updatedAt = std::chrono::system_clock::now();
    return true;
}

std::optional<Location> LocationService::getDriverLocation(const std::string& driverId) const {
    auto it = drivers_.find(driverId);
    if (it == drivers_.end()) return std::nullopt;
    return it->second.location;
}

std::optional<Location> LocationService::getRiderLocation(const std::string& riderId) const {
    auto it = riders_.find(riderId);
    if (it == riders_.end()) return std::nullopt;
    return it->second.location;
}

bool LocationService::isLocationStale(const Location& loc, std::chrono::seconds maxAge) const {
    auto age = std::chrono::system_clock::now() - loc.updatedAt;
    return age > maxAge;
}

} // namespace location
