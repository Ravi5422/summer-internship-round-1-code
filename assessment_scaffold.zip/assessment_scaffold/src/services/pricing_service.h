#pragma once

#include "../models/types.h"

namespace pricing {

// Part 1.3 — Surge pricing engine (rule-based, no ML).

// Base multiplier from time-of-day bucket (rush hours cost more).
double getTimeOfDayMultiplier(TimeOfDayBucket bucket);

// Multiplier from current demand vs available driver supply.
double getSupplyDemandMultiplier(int demand, int supply);

// Multiplier from predicted near-future demand spike.
double getForecastMultiplier(double predictedSpike);

// Combines all factors into a capped surge multiplier (min 1.0, max 3.0).
double calculateSurgeMultiplier(const PricingContext& ctx);

// Applies surge to base fare and returns the final price charged to the rider.
double calculateFinalFare(double baseFare, double surgeMultiplier);

} // namespace pricing
