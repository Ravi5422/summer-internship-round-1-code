#include "booking_service.h"

#include "../services/eta_service.h"
#include "../services/matching_service.h"
#include "../services/pricing_service.h"
#include "../services/recommendation_service.h"

namespace booking {

BookingService::BookingService(location::LocationService& locService)
    : locService_(locService) {}

bool BookingService::canTransition(RideStatus from, RideStatus to) const {
    switch (from) {
        case RideStatus::REQUESTED:   return to == RideStatus::ACCEPTED || to == RideStatus::CANCELLED;
        case RideStatus::ACCEPTED:    return to == RideStatus::IN_PROGRESS || to == RideStatus::CANCELLED;
        case RideStatus::IN_PROGRESS: return to == RideStatus::COMPLETED || to == RideStatus::CANCELLED;
        default: return false;
    }
}

bool BookingService::assignDriver(const std::string& driverId, const std::string& rideId) {
    auto& drivers = locService_.mutableDrivers();
    auto it = drivers.find(driverId);
    if (it == drivers.end() || it->second.status != DriverStatus::AVAILABLE) return false;

    it->second.status = DriverStatus::EN_ROUTE;
    it->second.activeRideId = rideId;
    return true;
}

void BookingService::releaseDriver(const std::string& driverId) {
    auto& drivers = locService_.mutableDrivers();
    auto it = drivers.find(driverId);
    if (it == drivers.end()) return;
    it->second.status = DriverStatus::AVAILABLE;
    it->second.activeRideId = std::nullopt;
}

std::optional<Ride> BookingService::requestRide(
    const std::string& rideId,
    const std::string& riderId,
    const Location& pickup,
    const Location& dropoff,
    const PricingContext& pricingCtx,
    TimeOfDayBucket timeBucket,
    int zoneId,
    bool useRecommendation) {

    if (rides_.count(rideId)) return std::nullopt;

    std::optional<std::string> driverId = useRecommendation
        ? recommend::recommendBestDriver(locService_, pickup)
        : matching::findNearestDriver(locService_, pickup);

    if (!driverId) return std::nullopt;

    auto driverIt = locService_.drivers().find(*driverId);
    if (driverIt == locService_.drivers().end()) return std::nullopt;

    double surge = pricing::calculateSurgeMultiplier(pricingCtx);
    double fare  = pricing::calculateFinalFare(pricingCtx.baseFare, surge);
    double eta   = eta::predictDriverToPointEtaMinutes(
        driverIt->second, pickup, timeBucket, zoneId);

    Ride ride;
    ride.id = rideId;
    ride.riderId = riderId;
    ride.driverId = *driverId;
    ride.status = RideStatus::REQUESTED;
    ride.pickup = pickup;
    ride.dropoff = dropoff;
    ride.baseFare = pricingCtx.baseFare;
    ride.surgeMultiplier = surge;
    ride.finalFare = fare;
    ride.estimatedEtaMinutes = eta;
    ride.requestedAt = std::chrono::system_clock::now();

    rides_[rideId] = ride;
    return ride;
}

bool BookingService::acceptRide(const std::string& rideId, const std::string& driverId) {
    auto it = rides_.find(rideId);
    if (it == rides_.end()) return false;
    if (!canTransition(it->second.status, RideStatus::ACCEPTED)) return false;
    if (!it->second.driverId || *it->second.driverId != driverId) return false;
    if (!assignDriver(driverId, rideId)) return false;

    it->second.status = RideStatus::ACCEPTED;
    return true;
}

bool BookingService::startRide(const std::string& rideId) {
    auto it = rides_.find(rideId);
    if (it == rides_.end()) return false;
    if (!canTransition(it->second.status, RideStatus::IN_PROGRESS)) return false;

    it->second.status = RideStatus::IN_PROGRESS;
    if (it->second.driverId) {
        auto& drivers = locService_.mutableDrivers();
        auto dIt = drivers.find(*it->second.driverId);
        if (dIt != drivers.end()) dIt->second.status = DriverStatus::ON_TRIP;
    }
    return true;
}

bool BookingService::completeRide(const std::string& rideId) {
    auto it = rides_.find(rideId);
    if (it == rides_.end()) return false;
    if (!canTransition(it->second.status, RideStatus::COMPLETED)) return false;

    it->second.status = RideStatus::COMPLETED;
    if (it->second.driverId) releaseDriver(*it->second.driverId);
    return true;
}

bool BookingService::cancelRide(const std::string& rideId) {
    auto it = rides_.find(rideId);
    if (it == rides_.end()) return false;
    if (!canTransition(it->second.status, RideStatus::CANCELLED)) return false;

    it->second.status = RideStatus::CANCELLED;
    if (it->second.driverId) releaseDriver(*it->second.driverId);
    return true;
}

std::optional<Ride> BookingService::getRide(const std::string& rideId) const {
    auto it = rides_.find(rideId);
    if (it == rides_.end()) return std::nullopt;
    return it->second;
}

} // namespace booking
