#include "matching_service.h"

#include "../utils/geo_utils.h"

#include <limits>

namespace matching {

std::vector<const Driver*> filterEligibleDrivers(
    const location::LocationService& locService,
    const Location& pickup,
    double maxRadiusKm,
    std::chrono::seconds maxLocationAge) {

    std::vector<const Driver*> eligible;
    for (const auto& [id, driver] : locService.drivers()) {
        if (driver.status != DriverStatus::AVAILABLE) continue;
        if (locService.isLocationStale(driver.location, maxLocationAge)) continue;
        if (!geo::isValidLocation(driver.location) || !geo::isValidLocation(pickup)) continue;

        double dist = geo::haversineKm(driver.location, pickup);
        if (dist <= maxRadiusKm) {
            eligible.push_back(&driver);
        }
    }
    return eligible;
}

std::optional<std::string> findNearestDriver(
    const location::LocationService& locService,
    const Location& pickup,
    double maxRadiusKm) {

    auto eligible = filterEligibleDrivers(
        locService, pickup, maxRadiusKm, std::chrono::seconds(120));

    if (eligible.empty()) return std::nullopt;

    const Driver* best = nullptr;
    double bestDist = std::numeric_limits<double>::max();

    for (const Driver* d : eligible) {
        double dist = geo::haversineKm(d->location, pickup);
        // Tie-break: prefer higher-rated driver when distances are equal.
        if (dist < bestDist
            || (dist == bestDist && best && d->rating > best->rating)) {
            bestDist = dist;
            best = d;
        }
    }
    return best ? std::optional<std::string>(best->id) : std::nullopt;
}

} // namespace matching
