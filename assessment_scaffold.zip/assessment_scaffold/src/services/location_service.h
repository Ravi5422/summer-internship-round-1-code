#pragma once

#include "../models/types.h"

#include <chrono>
#include <optional>
#include <string>
#include <unordered_map>

namespace location {

// In-memory store for live driver/rider positions.
class LocationService {
public:
    // Registers a driver so future location updates can find them.
    void registerDriver(const Driver& driver);

    // Registers a rider so future location updates can find them.
    void registerRider(const Rider& rider);

    // Updates a driver's GPS coordinates and refresh timestamp.
    bool updateDriverLocation(const std::string& driverId, const Location& loc);

    // Updates a rider's GPS coordinates and refresh timestamp.
    bool updateRiderLocation(const std::string& riderId, const Location& loc);

    // Returns the latest known driver location, if the driver exists.
    std::optional<Location> getDriverLocation(const std::string& driverId) const;

    // Returns the latest known rider location, if the rider exists.
    std::optional<Location> getRiderLocation(const std::string& riderId) const;

    // True if the location ping is older than maxAge (stale drivers are excluded from matching).
    bool isLocationStale(const Location& loc, std::chrono::seconds maxAge) const;

    // Read-only access to all registered drivers (used by matching/recommendation).
    const std::unordered_map<std::string, Driver>& drivers() const { return drivers_; }

    // Read-only access to all registered riders.
    const std::unordered_map<std::string, Rider>& riders() const { return riders_; }

    // Mutable driver access for status changes during booking.
    std::unordered_map<std::string, Driver>& mutableDrivers() { return drivers_; }

private:
    std::unordered_map<std::string, Driver> drivers_;
    std::unordered_map<std::string, Rider> riders_;
};

} // namespace location
