#pragma once

#include "../models/types.h"
#include "location_service.h"

#include <optional>
#include <string>
#include <vector>

namespace recommend {

// Part 1.5 — Driver recommendation: rank eligible drivers beyond just nearest.

struct DriverScore {
    std::string driverId;
    double totalScore = 0.0;
    double proximityScore = 0.0;
    double ratingScore = 0.0;
    double performanceScore = 0.0;
    double acceptanceScore = 0.0;
};

// Converts distance into a 0–1 score (closer = higher).
double computeProximityScore(double distanceKm, double maxRadiusKm);

// Normalizes driver rating (1–5) into a 0–1 score.
double computeRatingScore(double rating);

// Normalizes performance score into a 0–1 range for ranking.
double computePerformanceScore(double performance);

// Uses acceptance rate directly as a 0–1 score.
double computeAcceptanceScore(double acceptanceRate);

// Weighted sum of all sub-scores — higher is better.
double computeTotalScore(
    double proximity, double rating, double performance, double acceptance,
    double wProx = 0.45, double wRating = 0.25,
    double wPerf = 0.20, double wAccept = 0.10);

// Scores one driver relative to a pickup location.
DriverScore scoreDriver(
    const Driver& driver,
    const Location& pickup,
    double maxRadiusKm);

// Returns all eligible drivers sorted best-first by total score.
std::vector<DriverScore> rankDrivers(
    const location::LocationService& locService,
    const Location& pickup,
    double maxRadiusKm = 10.0);

// Convenience: returns the top-ranked driver id, or nullopt if none eligible.
std::optional<std::string> recommendBestDriver(
    const location::LocationService& locService,
    const Location& pickup,
    double maxRadiusKm = 10.0);

} // namespace recommend
