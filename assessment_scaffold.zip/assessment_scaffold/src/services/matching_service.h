#pragma once

#include "../models/types.h"
#include "location_service.h"

#include <optional>
#include <string>
#include <vector>

namespace matching {

// Returns drivers that are AVAILABLE, not stale, and within maxRadiusKm of pickup.
std::vector<const Driver*> filterEligibleDrivers(
    const location::LocationService& locService,
    const Location& pickup,
    double maxRadiusKm,
    std::chrono::seconds maxLocationAge);

// Part 1.2 — Picks the single closest eligible driver to the pickup point.
std::optional<std::string> findNearestDriver(
    const location::LocationService& locService,
    const Location& pickup,
    double maxRadiusKm = 10.0);

} // namespace matching
