#pragma once

#include "../models/types.h"

namespace eta {

// Part 1.4 — ETA prediction using simulated traffic and driver behavior.

// Raw travel time in minutes from distance and average city speed (km/h).
double estimateBaseTravelTimeMinutes(double distanceKm, double avgSpeedKmh = 30.0);

// Congestion delay factor from simulated traffic (>= 1.0 means slower).
double getTrafficDelayFactor(TimeOfDayBucket bucket, int zoneId);

// Per-driver speed adjustment based on historical performance.
double getDriverBehaviorFactor(const Driver& driver);

// Full ETA in minutes from driver location to a target point.
double predictDriverToPointEtaMinutes(
    const Driver& driver,
    const Location& target,
    TimeOfDayBucket bucket,
    int zoneId);

// Trip duration estimate from pickup to dropoff (used for fare/time display).
double predictTripDurationMinutes(
    const Location& pickup,
    const Location& dropoff,
    const Driver& driver,
    TimeOfDayBucket bucket,
    int zoneId);

} // namespace eta
