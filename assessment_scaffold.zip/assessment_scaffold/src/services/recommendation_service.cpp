#include "recommendation_service.h"

#include "../services/matching_service.h"
#include "../utils/geo_utils.h"

#include <algorithm>
#include <optional>

namespace recommend {

double computeProximityScore(double distanceKm, double maxRadiusKm) {
    if (maxRadiusKm <= 0.0) return 0.0;
    return std::max(0.0, 1.0 - (distanceKm / maxRadiusKm));
}

double computeRatingScore(double rating) {
    return std::clamp((rating - 1.0) / 4.0, 0.0, 1.0);
}

double computePerformanceScore(double performance) {
    // Map ~0.5–1.5 performance range into 0–1.
    return std::clamp((performance - 0.5) / 1.0, 0.0, 1.0);
}

double computeAcceptanceScore(double acceptanceRate) {
    return std::clamp(acceptanceRate, 0.0, 1.0);
}

double computeTotalScore(
    double proximity, double rating, double performance, double acceptance,
    double wProx, double wRating, double wPerf, double wAccept) {
    return wProx * proximity + wRating * rating + wPerf * performance + wAccept * acceptance;
}

DriverScore scoreDriver(
    const Driver& driver,
    const Location& pickup,
    double maxRadiusKm) {

    double dist = geo::haversineKm(driver.location, pickup);
    DriverScore result;
    result.driverId = driver.id;
    result.proximityScore  = computeProximityScore(dist, maxRadiusKm);
    result.ratingScore     = computeRatingScore(driver.rating);
    result.performanceScore = computePerformanceScore(driver.performanceScore);
    result.acceptanceScore = computeAcceptanceScore(driver.acceptanceRate);
    result.totalScore = computeTotalScore(
        result.proximityScore, result.ratingScore,
        result.performanceScore, result.acceptanceScore);
    return result;
}

std::vector<DriverScore> rankDrivers(
    const location::LocationService& locService,
    const Location& pickup,
    double maxRadiusKm) {

    auto eligible = matching::filterEligibleDrivers(
        locService, pickup, maxRadiusKm, std::chrono::seconds(120));

    std::vector<DriverScore> ranked;
    ranked.reserve(eligible.size());
    for (const Driver* d : eligible) {
        ranked.push_back(scoreDriver(*d, pickup, maxRadiusKm));
    }

    std::sort(ranked.begin(), ranked.end(),
        [](const DriverScore& a, const DriverScore& b) {
            return a.totalScore > b.totalScore;
        });
    return ranked;
}

std::optional<std::string> recommendBestDriver(
    const location::LocationService& locService,
    const Location& pickup,
    double maxRadiusKm) {

    auto ranked = rankDrivers(locService, pickup, maxRadiusKm);
    if (ranked.empty()) return std::nullopt;
    return ranked.front().driverId;
}

} // namespace recommend
