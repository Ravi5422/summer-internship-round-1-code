#include "pooling_service.h"

#include "../utils/geo_utils.h"

#include <algorithm>
#include <limits>
#include <unordered_map>

namespace pooling {

double calculateRouteDistanceKm(const std::vector<RouteStop>& stops) {
    if (stops.size() < 2) return 0.0;
    double total = 0.0;
    for (size_t i = 1; i < stops.size(); ++i) {
        total += geo::haversineKm(stops[i - 1].location, stops[i].location);
    }
    return total;
}

double calculateSoloRouteDistanceKm(const Location& pickup, const Location& dropoff) {
    return geo::haversineKm(pickup, dropoff);
}

double calculateDetourRatio(
    const std::vector<RouteStop>& poolStops,
    const std::string& rideId,
    const Location& pickup,
    const Location& dropoff) {

    double solo = calculateSoloRouteDistanceKm(pickup, dropoff);
    if (solo <= 0.0) return 1.0;

    // Extract sub-route distance for this rider (pickup stop → dropoff stop).
    int pickupIdx = -1, dropoffIdx = -1;
    for (size_t i = 0; i < poolStops.size(); ++i) {
        if (poolStops[i].rideId == rideId && poolStops[i].type == StopType::PICKUP)
            pickupIdx = static_cast<int>(i);
        if (poolStops[i].rideId == rideId && poolStops[i].type == StopType::DROPOFF)
            dropoffIdx = static_cast<int>(i);
    }
    if (pickupIdx < 0 || dropoffIdx < 0 || dropoffIdx <= pickupIdx) return std::numeric_limits<double>::max();

    std::vector<RouteStop> sub(poolStops.begin() + pickupIdx, poolStops.begin() + dropoffIdx + 1);
    return calculateRouteDistanceKm(sub) / solo;
}

bool isValidStopOrder(const std::vector<RouteStop>& stops) {
    std::unordered_map<std::string, int> pickupIndex;
    for (size_t i = 0; i < stops.size(); ++i) {
        const RouteStop& s = stops[i];
        if (s.type == StopType::PICKUP) {
            pickupIndex[s.rideId] = static_cast<int>(i);
        } else {
            auto it = pickupIndex.find(s.rideId);
            if (it == pickupIndex.end() || it->second >= static_cast<int>(i))
                return false;
        }
    }
    return true;
}

bool satisfiesDetourLimits(
    const std::vector<RouteStop>& stops,
    const std::vector<Ride>& ridesInPool,
    double maxDetourRatio) {

    for (const Ride& ride : ridesInPool) {
        double ratio = calculateDetourRatio(stops, ride.id, ride.pickup, ride.dropoff);
        if (ratio > maxDetourRatio) return false;
    }
    return true;
}

std::optional<std::vector<RouteStop>> findBestInsertion(
    const std::vector<RouteStop>& currentStops,
    const Ride& newRide,
    double maxDetourRatio) {

    RouteStop pickupStop{newRide.id, StopType::PICKUP, newRide.pickup};
    RouteStop dropoffStop{newRide.id, StopType::DROPOFF, newRide.dropoff};

    std::vector<RouteStop> bestRoute;
    double bestDistance = std::numeric_limits<double>::max();
    bool found = false;

    // Try every valid pickup/dropoff insertion pair.
    for (size_t p = 0; p <= currentStops.size(); ++p) {
        for (size_t d = p + 1; d <= currentStops.size() + 1; ++d) {
            std::vector<RouteStop> candidate = currentStops;
            candidate.insert(candidate.begin() + static_cast<long>(p), pickupStop);
            candidate.insert(candidate.begin() + static_cast<long>(d), dropoffStop);

            if (!isValidStopOrder(candidate)) continue;

            // Build temporary ride list for detour check (caller rides + new).
            std::vector<Ride> ridesForCheck;
            ridesForCheck.push_back(newRide);

            if (!satisfiesDetourLimits(candidate, ridesForCheck, maxDetourRatio)) continue;

            double dist = calculateRouteDistanceKm(candidate);
            if (dist < bestDistance) {
                bestDistance = dist;
                bestRoute = candidate;
                found = true;
            }
        }
    }
    return found ? std::optional<std::vector<RouteStop>>(bestRoute) : std::nullopt;
}

std::vector<RouteStop> buildPoolRoute(
    const std::vector<Ride>& rides,
    double maxDetourRatio,
    int maxPassengers) {

    if (rides.empty()) return {};

    // Single rider — no pooling needed, just direct pickup then dropoff.
    if (rides.size() == 1) {
        return {
            {rides[0].id, StopType::PICKUP,  rides[0].pickup},
            {rides[0].id, StopType::DROPOFF, rides[0].dropoff}
        };
    }

    std::vector<RouteStop> route = {
        {rides[0].id, StopType::PICKUP,  rides[0].pickup},
        {rides[0].id, StopType::DROPOFF, rides[0].dropoff}
    };

    std::vector<Ride> inPool = {rides[0]};

    for (size_t i = 1; i < rides.size() && static_cast<int>(inPool.size()) < maxPassengers; ++i) {
        auto inserted = findBestInsertion(route, rides[i], maxDetourRatio);
        if (!inserted) continue; // skip rider if pooling would exceed detour limit

        route = *inserted;
        inPool.push_back(rides[i]);
    }

    return route;
}

} // namespace pooling
