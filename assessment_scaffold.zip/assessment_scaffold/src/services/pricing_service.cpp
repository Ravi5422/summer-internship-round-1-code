#include "pricing_service.h"

#include <algorithm>

namespace pricing {

double getTimeOfDayMultiplier(TimeOfDayBucket bucket) {
    switch (bucket) {
        case TimeOfDayBucket::MORNING_RUSH:
        case TimeOfDayBucket::EVENING_RUSH: return 1.5;
        case TimeOfDayBucket::MIDDAY:         return 1.1;
        case TimeOfDayBucket::EARLY_MORNING:  return 1.0;
        case TimeOfDayBucket::LATE_NIGHT:     return 1.3;
    }
    return 1.0;
}

double getSupplyDemandMultiplier(int demand, int supply) {
    // Avoid division by zero when no drivers are online.
    double ratio = static_cast<double>(demand) / std::max(supply, 1);
    return 1.0 + 0.15 * ratio;
}

double getForecastMultiplier(double predictedSpike) {
    // predictedSpike is 0.0–1.0 from the demand forecaster.
    return 1.0 + 0.5 * std::clamp(predictedSpike, 0.0, 1.0);
}

double calculateSurgeMultiplier(const PricingContext& ctx) {
    double timeFactor    = getTimeOfDayMultiplier(ctx.timeBucket);
    double supplyFactor  = getSupplyDemandMultiplier(ctx.demandCount, ctx.supplyCount);
    double forecastFactor = getForecastMultiplier(ctx.predictedDemandSpike);

    double raw = timeFactor * supplyFactor * forecastFactor;
    return std::clamp(raw, 1.0, 3.0);
}

double calculateFinalFare(double baseFare, double surgeMultiplier) {
    return baseFare * surgeMultiplier;
}

} // namespace pricing
