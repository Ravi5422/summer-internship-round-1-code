#pragma once

#include "../models/types.h"

#include <optional>
#include <string>
#include <vector>

namespace pooling {

// Part 1.6 — Shared ride routing with greedy stop insertion.

// Total distance when visiting an ordered list of stops sequentially.
double calculateRouteDistanceKm(const std::vector<RouteStop>& stops);

// Distance for a single rider traveling directly pickup → dropoff.
double calculateSoloRouteDistanceKm(const Location& pickup, const Location& dropoff);

// How much longer a pooled route is vs solo, as a ratio (1.0 = no detour).
double calculateDetourRatio(
    const std::vector<RouteStop>& poolStops,
    const std::string& rideId,
    const Location& pickup,
    const Location& dropoff);

// Validates pickup-before-dropoff constraint for every ride in the stop list.
bool isValidStopOrder(const std::vector<RouteStop>& stops);

// Checks whether every rider's detour stays within maxDetourRatio.
bool satisfiesDetourLimits(
    const std::vector<RouteStop>& stops,
    const std::vector<Ride>& ridesInPool,
    double maxDetourRatio);

// Finds the cheapest valid position to insert a new ride's pickup/dropoff stops.
std::optional<std::vector<RouteStop>> findBestInsertion(
    const std::vector<RouteStop>& currentStops,
    const Ride& newRide,
    double maxDetourRatio);

// Builds an optimized multi-rider route; falls back to solo if pooling fails.
std::vector<RouteStop> buildPoolRoute(
    const std::vector<Ride>& rides,
    double maxDetourRatio = 1.25,
    int maxPassengers = 3);

} // namespace pooling
