#pragma once

#include "../models/types.h"
#include "location_service.h"

#include <optional>
#include <string>
#include <unordered_map>

namespace booking {

// Part 1.2 — Ride lifecycle orchestrator tying matching, pricing, and ETA together.

class BookingService {
public:
    explicit BookingService(location::LocationService& locService);

    // Creates a new ride request, calculates surge fare and ETA, assigns recommended driver.
    std::optional<Ride> requestRide(
        const std::string& rideId,
        const std::string& riderId,
        const Location& pickup,
        const Location& dropoff,
        const PricingContext& pricingCtx,
        TimeOfDayBucket timeBucket,
        int zoneId,
        bool useRecommendation = true);

    // Driver accepts a pending ride — transitions REQUESTED → ACCEPTED.
    bool acceptRide(const std::string& rideId, const std::string& driverId);

    // Marks ride as in progress when passenger is picked up.
    bool startRide(const std::string& rideId);

    // Completes the ride and frees the driver for new matches.
    bool completeRide(const std::string& rideId);
    

    // Cancels a ride before or during trip; releases driver if assigned.
    bool cancelRide(const std::string& rideId);

    // Lookup a ride by id.
    std::optional<Ride> getRide(const std::string& rideId) const;

    // All rides (for testing/demo).
    const std::unordered_map<std::string, Ride>& rides() const { return rides_; }

private:
    // Validates that a status transition is allowed by the state machine.
    bool canTransition(RideStatus from, RideStatus to) const;

    // Marks a driver as busy and links them to a ride.
    bool assignDriver(const std::string& driverId, const std::string& rideId);

    // Releases a driver back to AVAILABLE after ride ends or is cancelled.
    void releaseDriver(const std::string& driverId);

    location::LocationService& locService_;
    std::unordered_map<std::string, Ride> rides_;
};

} // namespace booking
