#include "eta_service.h"

#include "../simulators/world_simulator.h"
#include "../utils/geo_utils.h"

namespace eta {

double estimateBaseTravelTimeMinutes(double distanceKm, double avgSpeedKmh) {
    if (avgSpeedKmh <= 0.0) return 0.0;
    return (distanceKm / avgSpeedKmh) * 60.0;
}

double getTrafficDelayFactor(TimeOfDayBucket bucket, int zoneId) {
    return sim::simulateTrafficFactor(bucket, zoneId);
}

double getDriverBehaviorFactor(const Driver& driver) {
    // performanceScore > 1.0 means faster; invert for time multiplier.
    if (driver.performanceScore <= 0.0) return 1.0;
    return 1.0 / driver.performanceScore;
}

double predictDriverToPointEtaMinutes(
    const Driver& driver,
    const Location& target,
    TimeOfDayBucket bucket,
    int zoneId) {

    double distanceKm = geo::haversineKm(driver.location, target);
    double baseMinutes = estimateBaseTravelTimeMinutes(distanceKm);
    double traffic     = getTrafficDelayFactor(bucket, zoneId);
    double behavior    = getDriverBehaviorFactor(driver);

    // Small fixed buffer for stops, signals, parking.
    constexpr double bufferMinutes = 2.0;
    return baseMinutes * traffic * behavior + bufferMinutes;
}

double predictTripDurationMinutes(
    const Location& pickup,
    const Location& dropoff,
    const Driver& driver,
    TimeOfDayBucket bucket,
    int zoneId) {

    double distanceKm = geo::haversineKm(pickup, dropoff);
    double baseMinutes = estimateBaseTravelTimeMinutes(distanceKm);
    double traffic     = getTrafficDelayFactor(bucket, zoneId);
    double behavior    = getDriverBehaviorFactor(driver);
    return baseMinutes * traffic * behavior;
}

} // namespace eta
