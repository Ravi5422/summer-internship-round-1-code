#include "models/types.h"
#include "services/booking_service.h"
#include "services/location_service.h"
#include "services/pooling_service.h"
#include "services/pricing_service.h"
#include "services/recommendation_service.h"
#include "simulators/world_simulator.h"
#include "utils/time_utils.h"

#include <iostream>
#include <iomanip>

// Helper: prints a labeled value for demo output.
template<typename T>
void printLine(const std::string& label, const T& value) {
    std::cout << "  " << label << ": " << value << "\n";
}

int main() {
    std::cout << "=== Phase 1 Ride-Sharing Backend Demo ===\n\n";

    // ------------------------------------------------------------------
    // Part 1.1 — Set up drivers, riders, and simulated market context.
    // ------------------------------------------------------------------
    location::LocationService locService;

    Driver d1{"driver-1", {12.97, 77.59}, DriverStatus::AVAILABLE, 4.8, 1.1, 0.95};
    Driver d2{"driver-2", {12.98, 77.60}, DriverStatus::AVAILABLE, 4.2, 0.9, 0.80};
    Driver d3{"driver-3", {13.05, 77.70}, DriverStatus::AVAILABLE, 4.9, 1.2, 0.99};

    locService.registerDriver(d1);
    locService.registerDriver(d2);
    locService.registerDriver(d3);
    locService.registerRider(Rider{"rider-1", {12.9716, 77.5946}});

    auto now = std::chrono::system_clock::now();
    auto bucket = timeutil::getTimeOfDayBucket(now);
    int zoneId = 1;
    auto pricingCtx = sim::buildPricingContext(zoneId, bucket, 10.0);

    // ------------------------------------------------------------------
    // Part 1.5 — Rank drivers by proximity + rating + performance.
    // ------------------------------------------------------------------
    Location pickup{12.9716, 77.5946};
    std::cout << "[1.5] Driver Recommendation Ranking:\n";
    auto ranked = recommend::rankDrivers(locService, pickup);
    for (const auto& score : ranked) {
        std::cout << "  " << score.driverId
                  << " | total=" << std::fixed << std::setprecision(2) << score.totalScore
                  << " prox=" << score.proximityScore
                  << " rating=" << score.ratingScore << "\n";
    }
    std::cout << "\n";

    // ------------------------------------------------------------------
    // Part 1.2 + 1.3 + 1.4 — Book a ride (matching, surge, ETA).
    // ------------------------------------------------------------------
    booking::BookingService bookingService(locService);

    Location dropoff{13.010, 77.555};
    auto ride = bookingService.requestRide(
        "ride-1", "rider-1", pickup, dropoff, pricingCtx, bucket, zoneId);

    if (ride) {
        std::cout << "[1.2–1.4] Ride Requested:\n";
        printLine("Driver", *ride->driverId);
        printLine("Surge", ride->surgeMultiplier);
        printLine("Final fare", ride->finalFare);
        printLine("ETA (min)", ride->estimatedEtaMinutes);

        bookingService.acceptRide("ride-1", *ride->driverId);
        bookingService.startRide("ride-1");
        bookingService.completeRide("ride-1");
        std::cout << "  Status: COMPLETED\n\n";
    }

    // ------------------------------------------------------------------
    // Part 1.6 — Build a shared ride route for two passengers.
    // ------------------------------------------------------------------
    Ride poolRide1{"pool-ride-1", "rider-a", "driver-1", RideStatus::REQUESTED,
        {12.97, 77.59}, {13.02, 77.57}};
    Ride poolRide2{"pool-ride-2", "rider-b", "driver-1", RideStatus::REQUESTED,
        {12.98, 77.60}, {13.03, 77.58}};

    auto poolRoute = pooling::buildPoolRoute({poolRide1, poolRide2}, 1.25, 3);

    std::cout << "[1.6] Shared Ride Route:\n";
    for (size_t i = 0; i < poolRoute.size(); ++i) {
        const auto& stop = poolRoute[i];
        std::cout << "  Stop " << i << ": "
                  << (stop.type == StopType::PICKUP ? "PICKUP" : "DROPOFF")
                  << " ride=" << stop.rideId
                  << " (" << stop.location.lat << ", " << stop.location.lng << ")\n";
    }
    printLine("Total route km", pooling::calculateRouteDistanceKm(poolRoute));

    return 0;
}
