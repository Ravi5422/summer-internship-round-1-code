#pragma once

#include "../models/types.h"

#include <chrono>

namespace timeutil {

// Maps the current clock hour into a TimeOfDayBucket for pricing/traffic rules.
TimeOfDayBucket getTimeOfDayBucket(std::chrono::system_clock::time_point now);

// Returns the hour (0–23) from a system clock timestamp.
int getHour(std::chrono::system_clock::time_point now);

} // namespace timeutil
