#include "geo_utils.h"

#include <cmath>

namespace geo {

// Converts degrees to radians for trigonometric distance math.
static double toRadians(double degrees) {
    return degrees * M_PI / 180.0;
}

double haversineKm(const Location& a, const Location& b) {
    constexpr double earthRadiusKm = 6371.0;
    double dLat = toRadians(b.lat - a.lat);
    double dLng = toRadians(b.lng - a.lng);
    double lat1 = toRadians(a.lat);
    double lat2 = toRadians(b.lat);

    double h = std::sin(dLat / 2) * std::sin(dLat / 2)
             + std::cos(lat1) * std::cos(lat2)
             * std::sin(dLng / 2) * std::sin(dLng / 2);
    return 2.0 * earthRadiusKm * std::asin(std::sqrt(h));
}

double manhattanKm(const Location& a, const Location& b) {
    // Rough km-per-degree conversion at mid-latitudes.
    constexpr double kmPerLatDegree = 111.0;
    double kmPerLngDegree = 111.0 * std::cos(toRadians((a.lat + b.lat) / 2.0));
    return std::abs(a.lat - b.lat) * kmPerLatDegree
         + std::abs(a.lng - b.lng) * kmPerLngDegree;
}

bool isValidLocation(const Location& loc) {
    return loc.lat >= -90.0 && loc.lat <= 90.0
        && loc.lng >= -180.0 && loc.lng <= 180.0
        && !std::isnan(loc.lat) && !std::isnan(loc.lng);
}

} // namespace geo
