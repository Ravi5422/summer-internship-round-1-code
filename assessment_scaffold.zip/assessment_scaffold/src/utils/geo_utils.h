#pragma once

#include "../models/types.h"

namespace geo {

// Returns straight-line distance in kilometers using the haversine formula.
double haversineKm(const Location& a, const Location& b);

// Manhattan-style grid distance (useful as a cheap routing proxy in cities).
double manhattanKm(const Location& a, const Location& b);

// Checks whether coordinates are within valid Earth bounds.
bool isValidLocation(const Location& loc);

} // namespace geo
