#include "time_utils.h"

#include <ctime>

namespace timeutil {

int getHour(std::chrono::system_clock::time_point now) {
    std::time_t t = std::chrono::system_clock::to_time_t(now);
    std::tm localTime{};
#ifdef _WIN32
    localtime_s(&localTime, &t);
#else
    localtime_r(&t, &localTime);
#endif
    return localTime.tm_hour;
}

TimeOfDayBucket getTimeOfDayBucket(std::chrono::system_clock::time_point now) {
    int hour = getHour(now);

    if (hour >= 5 && hour < 8)  return TimeOfDayBucket::EARLY_MORNING;
    if (hour >= 8 && hour < 11) return TimeOfDayBucket::MORNING_RUSH;
    if (hour >= 11 && hour < 14) return TimeOfDayBucket::MIDDAY;
    if (hour >= 17 && hour < 20) return TimeOfDayBucket::EVENING_RUSH;
    return TimeOfDayBucket::LATE_NIGHT;
}

} // namespace timeutil
