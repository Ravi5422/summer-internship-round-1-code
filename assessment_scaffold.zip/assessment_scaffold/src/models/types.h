#pragma once

#include <chrono>
#include <optional>
#include <string>
#include <vector>

// ---------------------------------------------------------------------------
// Part 1.1 — Core domain models shared across all Phase 1 services.
// ---------------------------------------------------------------------------

enum class DriverStatus {
    OFFLINE,
    AVAILABLE,
    EN_ROUTE,
    ON_TRIP
};

enum class RideStatus {
    REQUESTED,
    ACCEPTED,
    IN_PROGRESS,
    COMPLETED,
    CANCELLED
};

enum class StopType { PICKUP, DROPOFF };

enum class TimeOfDayBucket {
    EARLY_MORNING,  // 05–08
    MORNING_RUSH,   // 08–11
    MIDDAY,         // 11–14
    EVENING_RUSH,   // 17–20
    LATE_NIGHT      // 20–05
};

// Geographic point with a timestamp so we can detect stale locations.
struct Location {
    double lat = 0.0;
    double lng = 0.0;
    std::chrono::system_clock::time_point updatedAt{std::chrono::system_clock::now()};
};

struct Driver {
    std::string id;
    Location location;
    DriverStatus status = DriverStatus::OFFLINE;
    double rating = 5.0;           // 1.0 – 5.0
    double performanceScore = 1.0; // 1.0 = average; >1 faster/better
    double acceptanceRate = 0.9;   // fraction of offers accepted
    std::optional<std::string> activeRideId;
};

struct Rider {
    std::string id;
    Location location;
    double rating = 5.0;
    std::optional<std::string> activeRideId;
};

struct Ride {
    std::string id;
    std::string riderId;
    std::optional<std::string> driverId;
    RideStatus status = RideStatus::REQUESTED;
    Location pickup;
    Location dropoff;
    double baseFare = 10.0;
    double surgeMultiplier = 1.0;
    double finalFare = 0.0;
    double estimatedEtaMinutes = 0.0;
    std::optional<std::string> poolRideId;
    std::chrono::system_clock::time_point requestedAt{std::chrono::system_clock::now()};
};

// A single stop in a pooled (shared) ride route.
struct RouteStop {
    std::string rideId;
    StopType type;
    Location location;
};

struct PoolRide {
    std::string id;
    std::string driverId;
    std::vector<RouteStop> stops; // ordered pickup/dropoff sequence
    std::vector<std::string> rideIds;
};

// Snapshot of market conditions used when calculating surge pricing.
struct PricingContext {
    TimeOfDayBucket timeBucket;
    int demandCount = 0;
    int supplyCount = 0;
    double predictedDemandSpike = 0.0; // 0.0 = normal, 1.0 = high spike
    double baseFare = 10.0;
};
