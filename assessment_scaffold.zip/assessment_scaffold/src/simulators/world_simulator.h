#pragma once

#include "../models/types.h"

namespace sim {

// Returns a congestion multiplier (>= 1.0) based on time bucket and zone id.
double simulateTrafficFactor(TimeOfDayBucket bucket, int zoneId);

// Simulates how many ride requests exist in a zone right now.
int simulateCurrentDemand(int zoneId, TimeOfDayBucket bucket);

// Simulates how many drivers are available in a zone right now.
int simulateCurrentSupply(int zoneId, TimeOfDayBucket bucket);

// Predicts near-future demand spike as a 0.0–1.0 scalar for surge pricing.
double predictFutureDemand(int zoneId, TimeOfDayBucket bucket);

// Builds a PricingContext snapshot from simulated market conditions.
PricingContext buildPricingContext(int zoneId, TimeOfDayBucket bucket, double baseFare);

} // namespace sim
