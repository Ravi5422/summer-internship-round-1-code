#include "world_simulator.h"

namespace sim {

// Lookup table: heavier traffic during rush hours, lighter at night.
double simulateTrafficFactor(TimeOfDayBucket bucket, int zoneId) {
    double base = 1.0 + (zoneId % 5) * 0.05; // slight zone variation
    switch (bucket) {
        case TimeOfDayBucket::MORNING_RUSH:
        case TimeOfDayBucket::EVENING_RUSH: return base + 0.6;
        case TimeOfDayBucket::MIDDAY:       return base + 0.2;
        case TimeOfDayBucket::EARLY_MORNING: return base + 0.1;
        case TimeOfDayBucket::LATE_NIGHT:   return base;
    }
    return base;
}

// Deterministic pseudo-random demand based on zone + time bucket.
int simulateCurrentDemand(int zoneId, TimeOfDayBucket bucket) {
    int base = 10 + zoneId * 3;
    switch (bucket) {
        case TimeOfDayBucket::MORNING_RUSH:
        case TimeOfDayBucket::EVENING_RUSH: return base + 25;
        case TimeOfDayBucket::MIDDAY:       return base + 10;
        case TimeOfDayBucket::EARLY_MORNING: return base + 5;
        case TimeOfDayBucket::LATE_NIGHT:   return base;
    }
    return base;
}

int simulateCurrentSupply(int zoneId, TimeOfDayBucket bucket) {
    int base = 8 + zoneId * 2;
    switch (bucket) {
        case TimeOfDayBucket::MORNING_RUSH:
        case TimeOfDayBucket::EVENING_RUSH: return base + 5;
        case TimeOfDayBucket::LATE_NIGHT:   return base - 3;
        default: return base;
    }
}

// Forecasts whether demand will rise soon (used by surge pricing).
double predictFutureDemand(int zoneId, TimeOfDayBucket bucket) {
    if (bucket == TimeOfDayBucket::EARLY_MORNING) return 0.7;
    if (bucket == TimeOfDayBucket::MORNING_RUSH)  return 0.5;
    if (bucket == TimeOfDayBucket::EVENING_RUSH)  return 0.6;
    if (bucket == TimeOfDayBucket::LATE_NIGHT && zoneId % 2 == 0) return 0.3;
    return 0.1;
}

PricingContext buildPricingContext(int zoneId, TimeOfDayBucket bucket, double baseFare) {
    return PricingContext{
        bucket,
        simulateCurrentDemand(zoneId, bucket),
        simulateCurrentSupply(zoneId, bucket),
        predictFutureDemand(zoneId, bucket),
        baseFare
    };
}

} // namespace sim
